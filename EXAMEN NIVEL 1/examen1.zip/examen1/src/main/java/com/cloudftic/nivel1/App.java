package com.cloudftic.nivel1;

public class App {
    public static void main( String[] args ){
       
    }
}
