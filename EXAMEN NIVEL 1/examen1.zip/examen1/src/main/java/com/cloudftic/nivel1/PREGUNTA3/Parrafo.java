package com.cloudftic.nivel1.PREGUNTA3;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Parrafo {
    private int numParrafo;
    private String contenidoParrafo;
}
